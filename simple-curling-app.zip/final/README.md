# Simple Curling Timer

A mobile-optimized web application for timing curling stone deliveries with three distinct modes and customizable settings.

## Overview

Simple Curling Timer is a touch-friendly timer designed specifically for curling practice. It helps players measure and improve their delivery timing across three common shot types: Button, Guard, and Takeout.

## Features

- **Three Timer Modes**: Button (3.65s default), Guard (3.90s default), and Takeout (3.00s default)
- **Press-and-Hold Timer**: Intuitive touch interface - press to start, release to stop
- **Real-Time Display**: Shows elapsed time in milliseconds
- **Color-Coded Feedback**: Instant visual feedback on performance
  - 🟢 **Green (Perfect)**: Within threshold of target time
  - 🟡 **Yellow (Slow)**: Slower than target by more than threshold
  - 🔴 **Red (Fast)**: Faster than target by more than threshold
- **Customizable Settings**: Adjust default times and threshold for each mode
- **Persistent Storage**: Settings are saved automatically and persist across sessions
- **Mobile-First Design**: Optimized for touch interactions on smartphones and tablets

## How to Use

### Starting the Timer

1. **Select a Mode**: Tap one of the three mode buttons (Button, Guard, or Takeout)
2. **Press and Hold**: Press and hold the large blue circular button to start the timer
3. **Release to Stop**: Release the button when you want to stop timing
4. **View Results**: The timer displays your time and provides color-coded feedback

### Understanding Feedback

#### For Button and Guard Modes:
- **Perfect (Green)**: Your time is within the threshold range of the default time
- **Slow (Yellow)**: Your time exceeds the default time by more than the threshold
- **Fast (Red)**: Your time is less than the default time by more than the threshold

#### For Takeout Mode (Special Rule):
- **Perfect (Green)**: Your time is equal to or less than the default time
- **Sweeping Needed (Yellow)**: Your time exceeds the default time (sweeping required)

### Adjusting Settings

1. **Open Settings**: Tap the settings icon (⚙️) in the top-right corner
2. **Adjust Values**: Use the scroll wheels to adjust:
   - **Button Default Time**: Target time for Button shots (adjustable in 50ms increments)
   - **Guard Default Time**: Target time for Guard shots (adjustable in 50ms increments)
   - **Takeout Default Time**: Target time for Takeout shots (adjustable in 50ms increments)
   - **Threshold**: Acceptable variance for "Perfect" timing (adjustable in 10ms increments)
3. **Save Changes**: Settings are saved automatically as you adjust them
4. **Return to Timer**: Tap the back arrow (←) to return to the main timer screen

### Default Settings

- **Button Mode**: 3.65 seconds (3650ms)
- **Guard Mode**: 3.90 seconds (3900ms)
- **Takeout Mode**: 3.00 seconds (3000ms)
- **Threshold**: 50 milliseconds

## Technical Details

### Browser Compatibility

The app works on modern mobile and desktop browsers:
- iOS Safari 12+
- Chrome for Android 80+
- Chrome/Edge/Firefox (desktop)

### Storage

Settings are stored locally in your browser using localStorage. Data persists across sessions but is specific to each browser/device.

### Touch Events

The timer supports both touch and mouse events for maximum compatibility:
- Touch events for mobile devices
- Mouse events for desktop testing
- Press-and-hold functionality prevents accidental starts/stops

## Tips for Best Results

1. **Calibrate Your Settings**: Adjust default times based on your ice conditions and delivery style
2. **Use Consistent Technique**: The timer measures from press to release - develop a consistent button-press rhythm
3. **Practice Regularly**: Use the color-coded feedback to identify trends in your timing
4. **Adjust Threshold**: If you're consistently getting "Perfect" or rarely achieving it, adjust the threshold accordingly

## Installation

Simply open `index.html` in a web browser. For mobile use:
1. Open the file in your mobile browser
2. Add to home screen for app-like experience (iOS Safari: Share → Add to Home Screen)

## File Structure

```
final/
├── index.html              # Main application interface
├── css/
│   └── styles.css         # All styling and responsive design
├── js/
│   ├── storage.js         # localStorage management
│   ├── timer.js           # Timer logic and mode management
│   └── settings.js        # Settings screen functionality
└── README.md              # This file
```

## Privacy

All data is stored locally on your device. No information is transmitted to external servers.

## Support

For issues or questions, please refer to the source code documentation in the JavaScript files.

---

**Version**: 1.0.0  
**Last Updated**: November 2025
